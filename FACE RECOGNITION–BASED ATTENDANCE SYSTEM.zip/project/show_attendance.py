import pandas as pd
from glob import glob

import tkinter as tk
from tkinter import *

def subjectchoose(text_to_speech):
    print(text_to_speech)
    text_to_speech("please Check the project folder for csv sheet in the name of subject")
    
